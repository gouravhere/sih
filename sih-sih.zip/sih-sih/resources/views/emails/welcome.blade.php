@component('mail::message')
# Hello

you have successfully signed up to be an alumni. Please wait until the college adimns verify you.


Thanks,<br>
{{ config('app.name') }}
@endcomponent